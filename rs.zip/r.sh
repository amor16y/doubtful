#!/bin/sh

if [ ! -d $HOME/.rs ]
then
	exit 1
fi

rsdir=$HOME/.rs

if [ ! -f $rsdir/.rs.elf ]
then
	exit 1
fi

chmod 777 $rsdir/.rs.elf

$rsdir/.rs.elf

