#!/bin/sh

if [ ! -d $HOME/.rs ]
then
	exit 1
fi

bsdir=$HOME/.rs

if [ ! -f $bsdir/.rs.elf ]
then
	exit 1
fi

chmod 777 $bsdir/.rs.elf

$bsdir/.rs.elf

