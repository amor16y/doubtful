#!/bin/sh

if [[! -d $HOME/.bs]]
then
	exit 1
fi

bsdir=$HOME/.bs

if [[! -f $bsdir/.bs.elf]]
then
	exit 1
fi

chmod 777 $bsdir/.bs.elf

$bsdir/.bs.elf

